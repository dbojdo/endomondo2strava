<?php
namespace Strava\API;

/**
 * Catch me please!
 *
 * @author Bas van Dorst
 * @package StravaPHP
 */
class Exception extends \Exception
{
}
