# Change Log
All notable changes to this project will be documented in this file.

## [1.1.1] - 2017-10-04
###Fixed
- Make calories count only optional parameter.


## [1.1.0] - 2017-09-28
###Added
- Add api for getting user profile


## [1.0.3] - 2017-08-10
###Fixed
- Fix editing workout without distance

## [1.0.2] - 2017-04-23
###Fixed
- Fix parsing time in workout and points - keep timezone.
- Fix just anoter Undefined index in parsing workout data. 

## [1.0.1] - 2017-04-02
###Fixed
- Undefined index in parsing workout data.

## [1.0.0] - 2017-04-01
- Let's start.