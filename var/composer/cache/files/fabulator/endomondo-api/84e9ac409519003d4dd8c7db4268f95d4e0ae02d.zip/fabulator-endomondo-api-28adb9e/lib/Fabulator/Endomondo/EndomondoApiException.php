<?php

namespace Fabulator\Endomondo;

/**
 * Class EndomondoAPIexception
 * @package Fabulator\Endomondo
 */
class EndomondoApiException extends \Exception {}