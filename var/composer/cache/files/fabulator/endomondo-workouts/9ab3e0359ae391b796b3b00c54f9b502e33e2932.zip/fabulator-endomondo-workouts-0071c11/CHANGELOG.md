# Change Log
All notable changes to this project will be documented in this file.

## [1.0.2] - 2017-08-31
Important fix! Timezone for GPX export was wrong.

## [1.0.1] - 2017-08-24
Add new Endomondo workout type.
Rename spinning to indoor cycling.

## [1.0.0] - 2017-03-31
Let's start.