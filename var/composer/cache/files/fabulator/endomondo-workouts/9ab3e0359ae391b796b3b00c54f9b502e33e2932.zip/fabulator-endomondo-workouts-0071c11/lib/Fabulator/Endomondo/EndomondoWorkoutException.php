<?php

namespace Fabulator\Endomondo;

/**
 * Class EndomondoWorkoutException
 * @package Fabulator\Endomondo
 */
class EndomondoWorkoutException extends \Exception {

}