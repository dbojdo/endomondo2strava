Endomondo Workouts
============

This library contain classes for manipulate with data from Endomondo Workouts. You can export them in GPX format. There are also important constants as Workout Types ids and names. This library is used for unofficials API packages - endomondo-api and endomondo-api-old.